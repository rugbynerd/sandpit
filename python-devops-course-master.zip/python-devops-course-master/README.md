![Python CI Steps Github Actions](https://github.com/noahgift/python-devops-course/workflows/Python%20CI%20Steps%20Github%20Actions/badge.svg)

[![CircleCI](https://circleci.com/gh/noahgift/python-devops-course.svg?style=svg)](https://circleci.com/gh/noahgift/python-devops-course)

# python-devops
A repo for a course on Python DevOps
